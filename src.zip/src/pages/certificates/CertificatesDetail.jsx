const CertificatesDetail = () => {
  return (
    <div className='mx-auto max-w-6xl p-4'>
      <img src='/sertifikat.png' alt='sertifikat' className='w-full' />
    </div>
  );
};

export default CertificatesDetail;
