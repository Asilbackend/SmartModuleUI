import { Empty } from 'antd';

const ModulesList = () => {
  return (
    <div className='mx-auto flex h-120 items-center justify-center'>
      <Empty />
    </div>
  );
};

export default ModulesList;
