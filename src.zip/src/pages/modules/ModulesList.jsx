import { useMutation, useQuery } from '@tanstack/react-query';
import { Empty, Skeleton, Steps } from 'antd';
import { BookOpenText, CheckCircle2, ChevronRight, Clock, Play, TvMinimalPlay } from 'lucide-react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { getModuleById, postStartContent } from 'src/api/modules.api';

export default function ModuleList() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const { data, isPending, error } = useQuery({
    queryKey: ['module-content', id],
    queryFn: async () => {
      const res = await getModuleById(id);
      return res.data || [];
    },
    enabled: !!id,
  });

  const moduleData = data || [];

  const startContentMutation = useMutation({
    mutationFn: (contentId) => postStartContent(contentId),
  });

  const handleStepClick = (sectionId, item, index) => {
    if (!item.isRead && index === 0) {
      startContentMutation.mutate(sectionId);
    }

    if (item.contentType === 'VIDEO') {
      navigate(`/modules/${id}/video/${item.attachmentId}`, {
        state: {
          contentId: sectionId,
          attachmentId: item.attachmentId,
          title: item.title,
          finish: item.isRead,
        },
      });
    } else if (item.contentType === 'TEXT') {
      navigate(`/modules/${id}/text/${item.title}`, {
        state: {
          title: item.title,
          contentId: sectionId,
          finish: item.isRead,
        },
      });
    } else {
      navigate(`/modules/${id}/file/${item.attachmentId}`, {
        state: {
          attachmentId: item.attachmentId,
          contentId: sectionId,
          finish: item.isRead,
        },
      });
    }
  };

  const ModuleSkeleton = () => {
    return (
      <div className='space-y-6 p-4 sm:p-6'>
        {/* Header Skeleton */}
        <div className='rounded-2xl border border-gray-100 bg-white p-4 shadow-sm sm:p-6'>
          <Skeleton.Input active size='large' className='!mb-3 !w-64' />
          <Skeleton active paragraph={{ rows: 2 }} />
        </div>

        {/* Content Skeletons */}
        {[1, 2].map((_, idx) => (
          <div
            key={idx}
            className='rounded-2xl border border-gray-100 bg-white p-4 shadow-sm sm:p-6'
          >
            <div className='mb-6 flex items-center justify-between'>
              <Skeleton.Input active size='default' className='!w-64' />
              <Skeleton.Button active size='small' shape='round' />
            </div>

            <div className='space-y-4'>
              {[...Array(3)].map((_, stepIdx) => (
                <div key={stepIdx} className='rounded-xl border border-gray-100 p-4'>
                  <div className='flex items-center justify-between'>
                    <div className='flex items-start gap-3'>
                      <Skeleton.Avatar active shape='circle' size={48} />
                      <div className='flex-1'>
                        <Skeleton active paragraph={{ rows: 1 }} />
                      </div>
                    </div>
                    <Skeleton.Button active size='small' shape='round' />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  if (isPending) return <ModuleSkeleton />;

  if (error) {
    return (
      <div className='p-4 sm:p-6'>
        <div className='rounded-2xl border border-red-200 bg-red-50 p-8 text-center sm:p-12'>
          <div className='mb-4 text-lg font-semibold text-red-600 sm:text-xl'>
            Xatolik yuz berdi
          </div>
          <p className='mb-6 text-sm text-gray-600 sm:text-base'>{error.message}</p>
          <button
            onClick={() => window.location.reload()}
            className='rounded-xl bg-red-600 px-6 py-2.5 text-sm font-medium text-white transition-all hover:bg-red-700'
          >
            Qayta urinish
          </button>
        </div>
      </div>
    );
  }

  if (!moduleData.length) {
    return (
      <div className='p-4 sm:p-6'>
        <div className='rounded-2xl border border-gray-100 bg-white p-12 shadow-sm sm:p-16'>
          <Empty description={<span className='text-gray-500'>Ma'lumot topilmadi</span>} />
        </div>
      </div>
    );
  }

  const { title, desc } = location.state || {};

  return (
    <div className='space-y-6 p-4 sm:p-6'>
      {/* Module Header */}
      <div className='rounded-2xl border border-gray-100 bg-gradient-to-br from-blue-50 to-white p-4 shadow-sm sm:p-6'>
        <div className='mb-3 flex items-center gap-2'>
          <div className='rounded-lg bg-blue-600 p-2'>
            <BookOpenText size={20} className='text-white' />
          </div>
          <h2 className='text-xl font-bold text-gray-900 sm:text-2xl'>{title}</h2>
        </div>
        <p className='text-sm leading-relaxed text-gray-600 sm:text-base'>{desc}</p>
      </div>

      {/* Module Sections */}
      {moduleData.map((section, i) => {
        const isCompleted = section.userContentStatus === 'COMPLETED';
        const nextSection = moduleData[i + 1];
        const canStartNext = isCompleted && nextSection?.userContentStatus === 'NOT_STARTED';

        const sortedAttachments = section.attachmentDetails.sort(
          (a, b) => a.order_element - b.order_element
        );

        const firstUnreadIndex = sortedAttachments.findIndex((item) => !item.isRead);

        return (
          <div
            key={section.contentId}
            className='group rounded-2xl border border-gray-100 bg-white shadow-sm transition-all hover:shadow-md'
          >
            {/* Section Header */}
            <div className='flex flex-col gap-3 border-b border-gray-100 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-6'>
              <h3 className='text-lg font-bold text-gray-900 sm:text-xl'>
                <span className='text-blue-600'>{i + 1}.</span> {section.contentTitle}
              </h3>

              <span
                className={`inline-flex w-fit items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold sm:text-sm ${
                  isCompleted
                    ? 'bg-green-50 text-green-700'
                    : section.isRequiredContent
                      ? 'bg-red-50 text-red-700'
                      : 'bg-blue-50 text-blue-700'
                }`}
              >
                {isCompleted && <CheckCircle2 size={14} />}
                {isCompleted ? 'Tugallangan' : section.isRequiredContent ? 'Majburiy' : 'Ixtiyoriy'}
              </span>
            </div>

            {/* Content Items */}
            <div className='space-y-3 p-4 sm:p-6'>
              {sortedAttachments.map((item, index) => {
                const isActive = index === firstUnreadIndex;
                const isCompleted = item.isRead;

                return (
                  <div
                    key={index}
                    className={`group/item relative overflow-hidden rounded-xl border transition-all ${
                      isCompleted
                        ? 'border-green-200 bg-green-50/50'
                        : isActive
                          ? 'border-blue-200 bg-blue-50/50'
                          : 'border-gray-200 bg-gray-50/50 hover:border-gray-300'
                    }`}
                  >
                    {/* Active Indicator */}
                    {isActive && !isCompleted && (
                      <div className='absolute top-0 left-0 h-full w-1 bg-blue-600' />
                    )}
                    {isCompleted && (
                      <div className='absolute top-0 left-0 h-full w-1 bg-green-600' />
                    )}

                    <div className='flex items-center justify-between gap-3 p-4'>
                      {/* Left Content */}
                      <div className='flex flex-1 items-start gap-3'>
                        {/* Icon */}
                        <div
                          className={`flex-shrink-0 rounded-xl p-2.5 transition-all ${
                            isCompleted
                              ? 'bg-green-100'
                              : item.contentType === 'VIDEO'
                                ? 'bg-blue-100'
                                : 'bg-purple-100'
                          }`}
                        >
                          {isCompleted ? (
                            <CheckCircle2 size={24} className='text-green-600' />
                          ) : item.contentType === 'VIDEO' ? (
                            <TvMinimalPlay size={24} className='text-blue-600' />
                          ) : (
                            <BookOpenText size={24} className='text-purple-600' />
                          )}
                        </div>

                        {/* Text Content */}
                        <div className='min-w-0 flex-1'>
                          <h4 className='mb-1.5 line-clamp-2 text-sm font-semibold text-gray-900 sm:text-base'>
                            {item.title}
                          </h4>
                          <div className='flex flex-wrap items-center gap-2'>
                            <span
                              className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
                                item.contentType === 'VIDEO'
                                  ? 'bg-blue-100 text-blue-700'
                                  : 'bg-purple-100 text-purple-700'
                              }`}
                            >
                              {item.contentType === 'VIDEO' ? (
                                <Play size={10} />
                              ) : (
                                <BookOpenText size={10} />
                              )}
                              {item.contentType}
                            </span>
                            {item.videoDuration && (
                              <span className='flex items-center gap-1 text-xs text-gray-500'>
                                <Clock size={12} />
                                {item.videoDuration}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right Button */}
                      <div className='flex-shrink-0'>
                        {isCompleted ? (
                          <button
                            onClick={() => handleStepClick(section.contentId, item)}
                            className='group/btn flex items-center gap-1.5 rounded-xl bg-green-100 px-3 py-2 text-xs font-medium text-green-700 transition-all hover:bg-green-200 sm:px-4 sm:text-sm'
                          >
                            <CheckCircle2 size={16} />
                            <span className='hidden sm:inline'>Ko'rilgan</span>
                            <ChevronRight
                              size={16}
                              className='transition-transform group-hover/btn:translate-x-0.5'
                            />
                          </button>
                        ) : isActive ? (
                          <button
                            onClick={() => handleStepClick(section.contentId, item, index)}
                            className='group/btn flex items-center gap-1.5 rounded-xl bg-blue-600 px-3 py-2 text-xs font-medium text-white shadow-sm transition-all hover:bg-blue-700 hover:shadow-md active:scale-95 sm:px-5 sm:text-sm'
                          >
                            <Play size={14} />
                            Boshlash
                            <ChevronRight
                              size={16}
                              className='transition-transform group-hover/btn:translate-x-0.5'
                            />
                          </button>
                        ) : (
                          <div className='rounded-xl bg-gray-200 px-3 py-2 text-xs font-medium text-gray-500 sm:px-4 sm:text-sm'>
                            Kutish
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Next Module Button */}
            {canStartNext && (
              <div className='border-t border-gray-100 p-4 sm:p-6'>
                <button
                  onClick={() => navigate(`/modules/${nextSection.contentId}`)}
                  className='group/next flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-green-600 to-green-700 px-5 py-3 font-semibold text-white shadow-lg transition-all hover:from-green-700 hover:to-green-800 hover:shadow-xl active:scale-95'
                >
                  Keyingi modulga o'tish
                  <ChevronRight
                    size={20}
                    className='transition-transform group-hover/next:translate-x-1'
                  />
                </button>
              </div>
            )}
          </div>
        );
      })}

      {/* Test Button */}
      <Link to={`/modules/${id}/test`}>
        <button className='group/test flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 text-base font-bold text-white shadow-lg transition-all hover:from-blue-700 hover:to-blue-800 hover:shadow-xl active:scale-95 sm:text-lg'>
          <BookOpenText size={20} />
          O'zingizni sinab ko'ring
          <ChevronRight size={20} className='transition-transform group-hover/test:translate-x-1' />
        </button>
      </Link>
    </div>
  );
}
